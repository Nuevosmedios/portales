<?php
// Check to ensure this file is included in Joomla!
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) {
	die( 'Direct Access to '.basename(__FILE__).' is not allowed.' );
}

if ( !defined( 'EDWIN2WIN_REGISTRATION_URL')) {
   define( 'EDWIN2WIN_REGISTRATION_URL', 'http://www.jms2win.com/index.php');
}
