//_jms2win_begin v1.2.84   MULTISITES_PATCH_JCE
    	'base_path' => WF_ADMINISTRATOR
//_jms2win_end
/*_jms2win_undo
    	'base_path' => dirname(__FILE__)
  _jms2win_undo */
