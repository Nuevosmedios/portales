//_jms2win_begin v1.2.52
if ( defined( 'MULTISITES_ID') && file_exists( dirname( __FILE__).DS.'enhanced_config_' . MULTISITES_ID . '.php')) {
   include( dirname( __FILE__).DS.'enhanced_config_' . MULTISITES_ID . '.php');
} else {
//_jms2win_end
