//_jms2win_begin v1.2.69
		if ( empty( $this->_params)) {
		   return $default;
		}
//_jms2win_end
