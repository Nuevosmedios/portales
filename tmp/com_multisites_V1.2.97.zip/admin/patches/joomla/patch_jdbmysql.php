//_jms2win_begin v1.2.69
		   session_write_close();
//_jms2win_end
