//_jms2win_begin v1.2.63
if ( !class_exists( 'ContentModelArticles')){
//_jms2win_end
