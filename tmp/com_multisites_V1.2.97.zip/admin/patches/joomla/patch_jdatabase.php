//_jms2win_begin v1.2.68
   function getAdapter( $adapter, $option) { return new $adapter( $option); }
//_jms2win_end
