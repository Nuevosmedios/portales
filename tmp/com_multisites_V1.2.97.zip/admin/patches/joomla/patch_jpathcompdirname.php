//_jms2win_begin v1.2.86  MULTISITES_ID
	define('JPATH_COMPONENT', JPATH_BASE . '/components/{option}');
//_jms2win_end
/*_jms2win_undo
	define( 'JPATH_COMPONENT' , dirname( __FILE__ ) );	
  _jms2win_undo */
