//_jms2win_begin v1.2.13
if ( !defined( 'MULTISITES_ID')) {
	   $config .= "} \n";
}
//_jms2win_end
