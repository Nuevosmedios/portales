//_jms2win_begin v1.2.60
if ( defined( 'MULTISITES_ID') && file_exists( dirname(__FILE__) .DIRECTORY_SEPARATOR. 'virtuemart.' .MULTISITES_ID. '.cfg.php')) {
   include_once( dirname(__FILE__) .DIRECTORY_SEPARATOR. 'virtuemart.' .MULTISITES_ID. '.cfg.php');
} else {
//_jms2win_end
