<?php // no direct access
defined('_JEXEC') or die('Restricted access');
// Redirect to the Joomla Multi Sites implementation
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_content'.DS.'elements'.DS.basename( __FILE__));
