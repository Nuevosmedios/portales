<?php
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_COMPONENT_ORIGINAL.DS.'view.php');

