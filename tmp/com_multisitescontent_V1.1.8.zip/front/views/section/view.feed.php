<?php // no direct access
defined('_JEXEC') or die('Restricted access');
// Redirect to the original content
require_once(JPATH_COMPONENT_ORIGINAL.DS.'views'.DS.'section'.DS.basename( __FILE__));
