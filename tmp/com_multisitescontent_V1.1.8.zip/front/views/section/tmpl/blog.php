<?php // no direct access
defined('_JEXEC') or die('Restricted access');
// Redirect to the original content
include(JPATH_COMPONENT_ORIGINAL.DS.'views'.DS.'section'.DS.'tmpl'.DS.basename( __FILE__));
