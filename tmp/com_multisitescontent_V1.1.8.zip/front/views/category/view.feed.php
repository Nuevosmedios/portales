<?php // no direct access
defined('_JEXEC') or die('Restricted access');
// Redirect to the original content
require_once( dirname( JPATH_COMPONENT) .DS. 'com_content'.DS.'views'.DS.'category'.DS.basename( __FILE__));