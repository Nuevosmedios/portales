<?php // no direct access
defined('_JEXEC') or die('Restricted access');
// Redirect to the original content
include(dirname( JPATH_COMPONENT).DS.'com_content'.DS.'views'.DS.'featured'.DS.'tmpl'.DS.basename( __FILE__));
