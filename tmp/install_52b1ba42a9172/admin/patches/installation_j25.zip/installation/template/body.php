<jdoc:include type="installation" />
