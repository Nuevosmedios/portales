<?php
@include( dirname( dirname( __FILE__)).DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_multisites'.DIRECTORY_SEPARATOR.'multisites_userexit.php');
if ( file_exists( dirname( dirname( __FILE__)).DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_multisitesaffiliate'.DIRECTORY_SEPARATOR.'multisites_userexit.php')) {
   @include( dirname( dirname( __FILE__)).DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_multisitesaffiliate'.DIRECTORY_SEPARATOR.'multisites_userexit.php');
}
