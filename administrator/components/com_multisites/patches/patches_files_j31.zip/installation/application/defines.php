<?php
/**
 * @package     Joomla.Installation
 * @subpackage  Application
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/*
 * Joomla! Installation Application Defines
 */

// Global definitions
$parts = explode(DIRECTORY_SEPARATOR, JPATH_BASE);
array_pop($parts);

// Defines
define('JPATH_ROOT',           implode(DIRECTORY_SEPARATOR, $parts));
define('JPATH_SITE',           JPATH_ROOT);
define('JPATH_ADMINISTRATOR',  JPATH_ROOT . '/administrator');
define('JPATH_LIBRARIES',      JPATH_ROOT . '/libraries');
define('JPATH_PLUGINS',        JPATH_ROOT . '/plugins');
if ( file_exists( JPATH_ROOT .DIRECTORY_SEPARATOR. 'includes'.DS. 'multisites_disable.php')) {}
else { @include_once ( JPATH_ROOT .DIRECTORY_SEPARATOR. 'includes'.DIRECTORY_SEPARATOR.'defines_multisites.php' ); }
if ( !defined( 'JPATH_CONFIGURATION'))  define('JPATH_CONFIGURATION',  JPATH_ROOT);
if ( !defined( 'JPATH_INSTALLATION'))   define('JPATH_INSTALLATION',   JPATH_ROOT . '/installation');
if ( !defined( 'JPATH_THEMES'))         define('JPATH_THEMES',         JPATH_BASE);
if ( !defined( 'JPATH_CACHE'))          define('JPATH_CACHE',          JPATH_BASE . '/cache');
if ( !defined( 'JPATH_MANIFESTS'))      define('JPATH_MANIFESTS',      JPATH_ADMINISTRATOR . '/manifests');
